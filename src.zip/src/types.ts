export type RecommendationType = 'PROMOTE' | 'BLOCK' | 'IGNORE' | 'REVIEW';

export interface SearchTermItem {
  row_id: string;
  search_term: string;
  match_type: string;
  campaign: string;
  ad_group: string;
  impressions: number;
  clicks: number;
  cost: number;
  conversions: number;
  conversion_value: number;
  recommendation: RecommendationType;
  intent_category: string;
  explanation: string;
  confidence: number;
  triggered_rules: string[];
  cvr: number;
  cpa: number;
  roas: number;
  reviewer_action?: RecommendationType;
  reviewer_notes?: string;
  reviewed_at?: string;
}

export interface ReviewItem {
  row_id: string;
  search_term: string;
  original_recommendation: RecommendationType;
  reviewer_action: RecommendationType;
  reviewer_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface SettingsData {
  businessName: string;
  businessDescription: string;
  supportedThemes: string[];
  unsupportedThemes: string[];
  minClicksThreshold: number;
  minSpendThreshold: number;
  minConversionsThreshold: number;
  confidenceThreshold: number;
  dataSourceMode: 'sample' | 'csv' | 'google_ads';
}

export interface ClusterGroup {
  clusterName: string;
  representativeTerm: string;
  terms: SearchTermItem[];
  totalImpressions: number;
  totalClicks: number;
  totalCost: number;
  totalConversions: number;
  totalValue: number;
  recommendations: Record<string, number>;
  hasConflict: boolean;
}
