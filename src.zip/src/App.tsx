import React, { useState, useEffect } from 'react';
import { SearchTermItem, RecommendationType } from './types';
import { fetchDemoSearchTerms, saveReview, fetchReviews } from './utils/triageClient';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { OverviewDashboard } from './components/OverviewDashboard';
import { ImportDataView } from './components/ImportDataView';
import { SearchTermsView } from './components/SearchTermsView';
import { ReviewQueueView } from './components/ReviewQueueView';
import { ClustersView } from './components/ClustersView';
import { ConflictsView } from './components/ConflictsView';
import { DecisionIntelligenceView } from './components/DecisionIntelligenceView';
import { ReportsView } from './components/ReportsView';
import { BenchmarksView } from './components/BenchmarksView';
import { SettingsView } from './components/SettingsView';
import { GoogleAdsConnectionView } from './components/GoogleAdsConnectionView';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [terms, setTerms] = useState<SearchTermItem[]>([]);
  const [dataSourceMode, setDataSourceMode] = useState<'sample' | 'csv' | 'google_ads'>('sample');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Load initial data (respecting localStorage cached CSV data if present, otherwise demo mode)
  const initializeApp = async () => {
    setIsRefreshing(true);
    try {
      const savedMode = localStorage.getItem('kestrel_datasource_mode');
      const savedTerms = localStorage.getItem('kestrel_uploaded_terms');
      const savedReviews = await fetchReviews();

      if (savedMode === 'csv' && savedTerms) {
        const parsed = JSON.parse(savedTerms);
        const merged = parsed.map((t: SearchTermItem) => {
          const found = savedReviews.find((r: any) => r.row_id === t.row_id || r.search_term === t.search_term);
          if (found) {
            return {
              ...t,
              reviewer_action: found.reviewer_action,
              reviewer_notes: found.reviewer_notes
            };
          }
          return t;
        });
        setTerms(merged);
        setDataSourceMode('csv');
      } else {
        await loadDemoMode();
      }
    } catch (err) {
      console.error(err);
      await loadDemoMode();
    } finally {
      setIsRefreshing(false);
    }
  };

  const loadDemoMode = async () => {
    setIsRefreshing(true);
    try {
      const demoTerms = await fetchDemoSearchTerms();
      const savedReviews = await fetchReviews();

      const merged = demoTerms.map(t => {
        const found = savedReviews.find((r: any) => r.row_id === t.row_id || r.search_term === t.search_term);
        if (found) {
          return {
            ...t,
            reviewer_action: found.reviewer_action,
            reviewer_notes: found.reviewer_notes
          };
        }
        return t;
      });

      setTerms(merged);
      setDataSourceMode('sample');
      localStorage.removeItem('kestrel_datasource_mode');
      localStorage.removeItem('kestrel_uploaded_terms');
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    initializeApp();
  }, []);

  const handleReviewUpdate = async (rowId: string, action: RecommendationType, notes?: string) => {
    const updated = terms.map(t => {
      if (t.row_id === rowId) {
        const updatedItem = {
          ...t,
          reviewer_action: action,
          reviewer_notes: notes !== undefined ? notes : t.reviewer_notes
        };
        saveReview({
          row_id: updatedItem.row_id,
          search_term: updatedItem.search_term,
          original_recommendation: updatedItem.recommendation,
          reviewer_action: action,
          reviewer_notes: updatedItem.reviewer_notes,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        return updatedItem;
      }
      return t;
    });
    setTerms(updated);
  };

  const handleDataLoaded = (newTerms: SearchTermItem[], mode: 'sample' | 'csv' | 'zip', stats?: { accepted: number; rejected: number; filename: string }) => {
    setTerms(newTerms);
    const m = mode === 'zip' ? 'csv' : mode;
    setDataSourceMode(m);
    setActiveTab('overview');
    if (m === 'csv') {
      localStorage.setItem('kestrel_datasource_mode', 'csv');
      localStorage.setItem('kestrel_uploaded_terms', JSON.stringify(newTerms));
    }
  };

  const handleRefresh = async () => {
    if (dataSourceMode === 'sample') {
      await loadDemoMode();
    } else {
      await initializeApp();
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-900 overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} dataSourceMode={dataSourceMode} onLoadDemo={loadDemoMode} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar
          dataSourceMode={dataSourceMode}
          totalTermsCount={terms.length}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
        />

        <main className="flex-1 overflow-y-auto p-8">
          {activeTab === 'overview' && <OverviewDashboard terms={terms} onNavigate={setActiveTab} onLoadDemo={loadDemoMode} />}
          {activeTab === 'import' && <ImportDataView onDataLoaded={handleDataLoaded} dataSourceMode={dataSourceMode} />}
          {activeTab === 'terms' && <SearchTermsView terms={terms} onReviewUpdate={handleReviewUpdate} />}
          {activeTab === 'review' && <ReviewQueueView terms={terms} onReviewUpdate={handleReviewUpdate} />}
          {activeTab === 'clusters' && <ClustersView terms={terms} />}
          {activeTab === 'conflicts' && <ConflictsView terms={terms} />}
          {activeTab === 'intelligence' && <DecisionIntelligenceView terms={terms} onReviewUpdate={handleReviewUpdate} />}
          {activeTab === 'reports' && <ReportsView terms={terms} />}
          {activeTab === 'benchmarks' && <BenchmarksView />}
          {activeTab === 'settings' && <SettingsView />}
          {activeTab === 'google_ads' && <GoogleAdsConnectionView onSyncLive={(newTerms) => {
            setTerms(newTerms);
            setDataSourceMode('google_ads');
            setActiveTab('overview');
          }} onNavigate={setActiveTab} onLoadDemo={loadDemoMode} />}
        </main>
      </div>
    </div>
  );
}
