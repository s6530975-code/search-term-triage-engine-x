import { SearchTermItem, ClusterGroup } from '../types';

export function clusterSearchTerms(terms: SearchTermItem[]): ClusterGroup[] {
  const map = new Map<string, SearchTermItem[]>();

  terms.forEach(term => {
    // Determine cluster key based on primary token / root theme
    const lower = term.search_term.toLowerCase();
    let key = "Other / General";
    if (lower.includes("working capital")) key = "Working Capital Loans";
    else if (lower.includes("equipment")) key = "Equipment Financing";
    else if (lower.includes("line of credit")) key = "Lines of Credit";
    else if (lower.includes("merchant cash") || lower.includes("mca")) key = "Merchant Cash Advance";
    else if (lower.includes("sba")) key = "SBA Loans";
    else if (lower.includes("personal") || lower.includes("mortgage") || lower.includes("car") || lower.includes("student")) key = "Unsupported / Non-Business";
    else if (lower.includes("kestrel") || lower.includes("login") || lower.includes("phone")) key = "Brand & Navigational";

    if (!map.has(key)) {
      map.set(key, []);
    }
    map.get(key)!.push(term);
  });

  const clusters: ClusterGroup[] = [];

  map.forEach((clusterTerms, clusterName) => {
    let totalImpressions = 0;
    let totalClicks = 0;
    let totalCost = 0;
    let totalConversions = 0;
    let totalValue = 0;
    const recommendations: Record<string, number> = { PROMOTE: 0, BLOCK: 0, IGNORE: 0, REVIEW: 0 };

    clusterTerms.forEach(t => {
      totalImpressions += Number(t.impressions) || 0;
      totalClicks += Number(t.clicks) || 0;
      totalCost += Number(t.cost) || 0;
      totalConversions += Number(t.conversions) || 0;
      totalValue += Number(t.conversion_value) || 0;
      const rec = t.reviewer_action || t.recommendation || 'REVIEW';
      recommendations[rec] = (recommendations[rec] || 0) + 1;
    });

    const activeRecsCount = Object.values(recommendations).filter(v => v > 0).length;
    const hasConflict = activeRecsCount > 1;

    clusters.push({
      clusterName,
      representativeTerm: clusterTerms[0]?.search_term || clusterName,
      terms: clusterTerms,
      totalImpressions,
      totalClicks,
      totalCost: Number(totalCost.toFixed(2)),
      totalConversions,
      totalValue: Number(totalValue.toFixed(2)),
      recommendations,
      hasConflict
    });
  });

  return clusters;
}
