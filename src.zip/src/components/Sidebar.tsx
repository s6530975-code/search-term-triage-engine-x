import React from 'react';
import { 
  LayoutDashboard, 
  Upload, 
  Search, 
  CheckSquare, 
  Layers, 
  AlertTriangle, 
  FileText, 
  BarChart2, 
  Settings, 
  Globe,
  ShieldCheck,
  Zap,
  Sparkles
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  dataSourceMode: string;
  onLoadDemo: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, dataSourceMode, onLoadDemo }) => {
  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'import', label: 'Import Data', icon: Upload },
    { id: 'terms', label: 'Search Terms', icon: Search },
    { id: 'review', label: 'Review Queue', icon: CheckSquare },
    { id: 'clusters', label: 'Clusters', icon: Layers },
    { id: 'conflicts', label: 'Conflicts', icon: AlertTriangle },
    { id: 'intelligence', label: 'Decision Intelligence', icon: Sparkles },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'benchmarks', label: 'Benchmarks', icon: BarChart2 },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'google_ads', label: 'Google Ads Connection', icon: Globe },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800 flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
          <Zap className="h-6 w-6" />
        </div>
        <div>
          <h1 className="font-bold text-white text-base tracking-tight leading-tight">Search Term Triage</h1>
          <p className="text-xs text-blue-400 font-medium">Kestrel Business Funding</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
          Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer Status & Demo Launch */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/50 space-y-3">
        <button
          onClick={onLoadDemo}
          className="w-full py-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
        >
          <Sparkles className="h-3.5 w-3.5 text-blue-400" />
          <span>Launch Demo Mode</span>
        </button>

        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">Active Source:</span>
          <span className={`px-2 py-0.5 rounded-full font-semibold text-[10px] uppercase ${
            dataSourceMode === 'google_ads' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
            dataSourceMode === 'csv' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
            'bg-blue-500/20 text-blue-400 border border-blue-500/30'
          }`}>
            {dataSourceMode === 'google_ads' ? 'Google Ads Live' : dataSourceMode === 'csv' ? 'Uploaded CSV' : 'SAMPLE DATASET'}
          </span>
        </div>
      </div>
    </aside>
  );
};
