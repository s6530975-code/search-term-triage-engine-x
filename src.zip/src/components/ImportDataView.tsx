import React, { useState, useRef } from 'react';
import { SearchTermItem } from '../types';
import Papa from 'papaparse';
import JSZip from 'jszip';
import { Upload, FileText, Download, CheckCircle, AlertCircle, Archive } from 'lucide-react';

interface ImportDataViewProps {
  onDataLoaded: (terms: SearchTermItem[], mode: 'sample' | 'csv' | 'zip', stats?: { accepted: number; rejected: number; filename: string }) => void;
  dataSourceMode: string;
}

export const ImportDataView: React.FC<ImportDataViewProps> = ({ onDataLoaded, dataSourceMode }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [importStats, setImportStats] = useState<{ accepted: number; rejected: number; filename: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setLoading(true);
    setImportStats(null);

    const fileName = file.name.toLowerCase();

    if (fileName.endsWith('.zip')) {
      try {
        const zip = new JSZip();
        const zipContent = await zip.loadAsync(file);
        
        let csvFileKey = Object.keys(zipContent.files).find(filename => filename.includes('search_terms_report.csv') || filename.endsWith('.csv'));
        
        if (!csvFileKey) {
          setError('Could not find "search_terms_report.csv" or any valid CSV file inside the uploaded ZIP archive.');
          setLoading(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        const csvText = await zipContent.files[csvFileKey].async('text');
        parseCSVText(csvText, 'zip', file.name);
      } catch (err: any) {
        setLoading(false);
        setError(`Failed to extract ZIP archive: ${err.message || 'Unknown error'}`);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    } else if (fileName.endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        parseCSVText(text, 'csv', file.name);
      };
      reader.onerror = () => {
        setLoading(false);
        setError('Failed to read uploaded CSV file.');
        if (fileInputRef.current) fileInputRef.current.value = '';
      };
      reader.readAsText(file);
    } else {
      setLoading(false);
      setError('Please upload a valid .zip dataset archive or .csv search terms report file.');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const parseCSVText = (csvText: string, mode: 'csv' | 'zip', filename: string) => {
    Papa.parse(csvText, {
      header: true,
      skipEmptyLines: 'greedy',
      transformHeader: (header) => header.trim().toLowerCase().replace(/\s+/g, '_'),
      complete: (results) => {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';

        const rows = results.data as any[];
        if (!rows || rows.length === 0) {
          setError('The dataset file is empty or improperly formatted.');
          return;
        }

        // Validate required columns
        const sampleRow = rows[0];
        const requiredColumns = ['row_id', 'search_term', 'match_type', 'campaign', 'ad_group', 'impressions', 'clicks', 'cost', 'conversions', 'conversion_value'];
        const missingColumns = requiredColumns.filter(col => !(col in sampleRow));

        if (missingColumns.length > 0) {
          setError(`Missing required CSV columns: ${missingColumns.join(', ')}. Please verify against schema template.`);
          return;
        }

        let accepted = 0;
        let rejected = 0;
        const parsedTerms: SearchTermItem[] = [];
        const seenIds = new Set<string>();

        rows.forEach((r, idx) => {
          const searchTerm = r.search_term;
          if (!searchTerm || typeof searchTerm !== 'string' || searchTerm.trim() === '') {
            rejected++;
            return;
          }

          const rowId = r.row_id || `ROW-${idx + 1}`;
          if (seenIds.has(rowId)) {
            rejected++;
            return;
          }
          seenIds.add(rowId);

          const cost = Number(r.cost);
          const clicks = Number(r.clicks);
          const conversions = Number(r.conversions);
          const conversionValue = Number(r.conversion_value);
          const impressions = Number(r.impressions);

          if (!isFinite(cost) || cost < 0 || !isFinite(clicks) || clicks < 0 || !isFinite(conversions) || conversions < 0 || !isFinite(conversionValue) || conversionValue < 0 || !isFinite(impressions) || impressions < 0) {
            rejected++;
            return;
          }

          accepted++;
          const cvr = clicks > 0 ? (conversions / clicks) * 100 : 0;
          const cpa = conversions > 0 ? cost / conversions : cost;
          const roas = cost > 0 ? conversionValue / cost : 0;

          const termText = searchTerm.toLowerCase();
          let rec = 'REVIEW';
          let intent = 'Ambiguous intent';
          let explanation = 'Search term ingested from dataset awaiting triage rule evaluation.';
          let confidence = 75;

          const isUnsupported = termText.includes('personal loan') || termText.includes('mortgage') || termText.includes('car loan') || termText.includes('student loan') || termText.includes('grant') || termText.includes('job') || termText.includes('career');
          const isRelevant = termText.includes('working capital') || termText.includes('equipment') || termText.includes('line of credit') || termText.includes('merchant cash') || termText.includes('sba') || termText.includes('business loan');

          if (isUnsupported) {
            rec = 'BLOCK';
            intent = termText.includes('grant') ? 'Unsupported product intent' : termText.includes('job') ? 'Employment intent' : 'Irrelevant intent';
            explanation = 'Term conflicts with Kestrel business lending scope (unsupported product / personal loan / grant / hiring).';
            confidence = 96;
          } else if (isRelevant) {
            if (conversions >= 1 && roas >= 2.0) {
              rec = 'PROMOTE';
              intent = 'High commercial intent';
              explanation = `Strong performance with ${conversions} conversions and ${roas.toFixed(2)}x ROAS on core business funding query.`;
              confidence = 90;
            } else if (clicks >= 15 && conversions === 0) {
              rec = 'BLOCK';
              intent = 'Irrelevant intent';
              explanation = `High spend ($${cost.toFixed(2)}) and ${clicks} clicks with zero conversions indicating wasteful traffic.`;
              confidence = 85;
            } else {
              rec = 'REVIEW';
              intent = 'Research intent';
              explanation = `Relevant query with moderate evidence (${clicks} clicks, ${conversions} conversions).`;
              confidence = 70;
            }
          } else {
            if (clicks > 30 && conversions === 0) {
              rec = 'BLOCK';
              intent = 'Irrelevant intent';
              explanation = 'Generic query with high traffic and zero conversions generating ad waste.';
              confidence = 80;
            } else {
              rec = 'REVIEW';
              intent = 'Ambiguous intent';
              explanation = 'Unclassified search term requiring reviewer verification.';
              confidence = 65;
            }
          }

          parsedTerms.push({
            row_id: rowId,
            search_term: searchTerm,
            match_type: r.match_type || 'Broad',
            campaign: r.campaign || 'Kestrel Performance Campaign',
            ad_group: r.ad_group || 'Default Ad Group',
            impressions,
            clicks,
            cost,
            conversions,
            conversion_value: conversionValue,
            recommendation: rec as any,
            intent_category: intent,
            explanation,
            confidence,
            triggered_rules: ['Dataset Ingestion & Rules Engine v2.4'],
            cvr: Number(cvr.toFixed(2)),
            cpa: Number(cpa.toFixed(2)),
            roas: Number(roas.toFixed(2))
          });
        });

        const stats = { accepted, rejected, filename };
        setImportStats(stats);
        onDataLoaded(parsedTerms, mode === 'zip' ? 'zip' : 'csv', stats);
      },
      error: (err: any) => {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
        setError(`CSV Parsing Error: ${err.message}`);
      }
    });
  };

  const handleDownloadTemplate = () => {
    const csvContent = "row_id,search_term,match_type,campaign,ad_group,impressions,clicks,cost,conversions,conversion_value\n" +
      "ROW-9001,working capital business loan,Phrase,Working Capital US,Loans,12500,820,3100.00,45,22500.00\n" +
      "ROW-9002,personal debt loan,Broad,Working Capital US,General,21000,1400,4200.00,0,0.00";
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'search_terms_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Archive className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Upload Dataset ZIP or CSV</h2>
            <p className="text-sm text-slate-500">Upload your test sample CSV (e.g. search_term_triage_test_sample.csv) or ZIP archive containing search_terms_report.csv.</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-3 text-red-700 text-sm">
          <AlertCircle className="h-5 w-5 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {importStats && (
        <div className="p-5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2">
          <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
            <CheckCircle className="h-5 w-5 text-emerald-600" />
            <span>Dataset Ingestion Complete ({importStats.filename})</span>
          </div>
          <div className="grid grid-cols-2 gap-4 pt-1 text-xs text-emerald-900">
            <div>Accepted Rows: <span className="font-bold">{importStats.accepted.toLocaleString()}</span></div>
            <div>Rejected Rows: <span className="font-bold text-red-600">{importStats.rejected.toLocaleString()}</span></div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-2xl border-2 border-dashed border-slate-300 hover:border-blue-500 transition-all flex flex-col items-center justify-center text-center space-y-4">
          <div className="h-16 w-16 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
            <Upload className="h-8 w-8" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-base">Upload ZIP Archive or CSV</h3>
            <p className="text-xs text-slate-500 mt-1">Accepts 10-column schema CSV files or ZIP archives.</p>
          </div>
          <label className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm rounded-xl shadow-md shadow-blue-600/30 cursor-pointer transition-all">
            <span>Choose ZIP / CSV File</span>
            <input ref={fileInputRef} type="file" accept=".zip,.csv" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 text-base">Ingestion Validation</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Validates all 10 required columns (`row_id`, `search_term`, `match_type`, `campaign`, `ad_group`, `impressions`, `clicks`, `cost`, `conversions`, `conversion_value`), normalizes headers, validates finite numbers, and reports accepted/rejected rows.
            </p>
          </div>
          <div className="space-y-3">
            <button
              onClick={handleDownloadTemplate}
              className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm rounded-xl transition-all flex items-center justify-center gap-2 border border-slate-200"
            >
              <Download className="h-4 w-4 text-slate-600" />
              <span>Download CSV Template</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
