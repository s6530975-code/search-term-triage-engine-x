import React, { useState } from 'react';
import { SearchTermItem, RecommendationType } from '../types';
import { CheckSquare, CheckCircle, AlertTriangle, Filter, Search, MessageSquare, ShieldCheck } from 'lucide-react';

interface ReviewQueueViewProps {
  terms: SearchTermItem[];
  onReviewUpdate: (rowId: string, action: RecommendationType, notes?: string) => void;
}

export const ReviewQueueView: React.FC<ReviewQueueViewProps> = ({ terms, onReviewUpdate }) => {
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PENDING' | 'REVIEWED'>('PENDING');
  const [searchQuery, setSearchQuery] = useState('');

  // Items needing review (either recommendation is REVIEW or terms that haven't been finalized)
  const reviewQueueItems = terms.filter(t => {
    const isPending = !t.reviewer_action || t.recommendation === 'REVIEW';
    const matchesStatus = filterStatus === 'ALL' || (filterStatus === 'PENDING' ? isPending : !isPending);
    const matchesSearch = t.search_term.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.campaign.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Review Queue & Human Overrides</h2>
          <p className="text-sm text-slate-500">Approve engine recommendations or override with human review and notes.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterStatus('PENDING')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'PENDING' ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Pending Review ({terms.filter(t => !t.reviewer_action || t.recommendation === 'REVIEW').length})
          </button>
          <button
            onClick={() => setFilterStatus('REVIEWED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'REVIEWED' ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'ALL' ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Items
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center gap-3">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search review items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent text-xs font-medium text-slate-800 focus:outline-none w-full"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                <th className="p-3.5">Search Term</th>
                <th className="p-3.5">Campaign</th>
                <th className="p-3.5 text-right">Metrics (Clicks / Cost / Conv)</th>
                <th className="p-3.5 text-center">Engine Rec</th>
                <th className="p-3.5 text-center">Reviewer Action</th>
                <th className="p-3.5">Reviewer Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {reviewQueueItems.map((t) => {
                const currentAction = t.reviewer_action || t.recommendation;
                return (
                  <tr key={t.row_id} className="hover:bg-slate-50/80">
                    <td className="p-3.5 font-semibold text-slate-900">
                      <div>{t.search_term}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{t.intent_category}</div>
                    </td>
                    <td className="p-3.5 text-slate-600 font-medium">{t.campaign}</td>
                    <td className="p-3.5 text-right text-slate-700">
                      <div>{t.clicks} clicks | ${t.cost.toFixed(2)}</div>
                      <div className="text-[10px] text-slate-400">{t.conversions} conv | {t.roas.toFixed(2)}x ROAS</div>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                        {t.recommendation} ({t.confidence}%)
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {(['PROMOTE', 'BLOCK', 'IGNORE'] as RecommendationType[]).map((act) => (
                          <button
                            key={act}
                            onClick={() => onReviewUpdate(t.row_id, act, t.reviewer_notes)}
                            className={`px-2 py-1 rounded text-[10px] font-bold transition-all border ${
                              currentAction === act
                                ? act === 'PROMOTE' ? 'bg-emerald-600 text-white border-emerald-600' :
                                  act === 'BLOCK' ? 'bg-red-600 text-white border-red-600' :
                                  'bg-slate-700 text-white border-slate-700'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            {act}
                          </button>
                        ))}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <input
                        type="text"
                        placeholder="Add review notes..."
                        defaultValue={t.reviewer_notes || ''}
                        onBlur={(e) => onReviewUpdate(t.row_id, currentAction, e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                      />
                    </td>
                  </tr>
                );
              })}
              {reviewQueueItems.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No items in the review queue matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
