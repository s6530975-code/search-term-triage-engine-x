import React from 'react';
import { SearchTermItem } from '../types';
import { 
  TrendingUp, 
  DollarSign, 
  Target, 
  AlertOctagon, 
  CheckCircle2, 
  ArrowUpRight,
  Sparkles,
  Upload,
  Database,
  RefreshCcw,
  Info
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';

interface OverviewDashboardProps {
  terms: SearchTermItem[];
  onNavigate: (tab: string) => void;
  onLoadDemo: () => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({ terms, onNavigate, onLoadDemo }) => {
  if (terms.length === 0) {
    return (
      <div className="max-w-3xl mx-auto py-16 text-center space-y-6">
        <div className="h-20 w-20 rounded-3xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center shadow-md">
          <Database className="h-10 w-10" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-slate-900">Welcome to Search Term Triage Engine</h2>
          <p className="text-sm text-slate-500 max-w-lg mx-auto leading-relaxed">
            Launch Demo Mode instantly with sample data for Kestrel Business Funding, or upload your dataset ZIP archive / test CSV.
          </p>
        </div>
        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={onLoadDemo}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2"
          >
            <Sparkles className="h-4 w-4" />
            <span>Try Demo Mode (Sample Data)</span>
          </button>
          <button
            onClick={() => onNavigate('import')}
            className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm rounded-xl shadow-md transition-all flex items-center gap-2"
          >
            <Upload className="h-4 w-4" />
            <span>Import Dataset ZIP / CSV</span>
          </button>
        </div>
      </div>
    );
  }

  const totalTerms = terms.length;
  const totalImpressions = terms.reduce((acc, t) => acc + (Number(t.impressions) || 0), 0);
  const totalClicks = terms.reduce((acc, t) => acc + (Number(t.clicks) || 0), 0);
  const totalCost = terms.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);
  const totalConversions = terms.reduce((acc, t) => acc + (Number(t.conversions) || 0), 0);
  const totalValue = terms.reduce((acc, t) => acc + (Number(t.conversion_value) || 0), 0);

  const overallCVR = totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0;
  const overallCPA = totalConversions > 0 ? totalCost / totalConversions : 0;
  const overallROAS = totalCost > 0 ? totalValue / totalCost : 0;

  const counts = {
    PROMOTE: terms.filter(t => (t.reviewer_action || t.recommendation) === 'PROMOTE').length,
    BLOCK: terms.filter(t => (t.reviewer_action || t.recommendation) === 'BLOCK').length,
    IGNORE: terms.filter(t => (t.reviewer_action || t.recommendation) === 'IGNORE').length,
    REVIEW: terms.filter(t => (t.reviewer_action || t.recommendation) === 'REVIEW').length,
  };

  const pieData = [
    { name: 'Promote', value: counts.PROMOTE, color: '#10B981' },
    { name: 'Block', value: counts.BLOCK, color: '#EF4444' },
    { name: 'Ignore', value: counts.IGNORE, color: '#6B7280' },
    { name: 'Review', value: counts.REVIEW, color: '#F59E0B' },
  ];

  const campaignMap: Record<string, { cost: number; conversions: number; value: number }> = {};
  terms.forEach(t => {
    const camp = t.campaign || 'Unknown Campaign';
    if (!campaignMap[camp]) {
      campaignMap[camp] = { cost: 0, conversions: 0, value: 0 };
    }
    campaignMap[camp].cost += Number(t.cost) || 0;
    campaignMap[camp].conversions += Number(t.conversions) || 0;
    campaignMap[camp].value += Number(t.conversion_value) || 0;
  });

  const campaignChartData = Object.keys(campaignMap).map(camp => ({
    name: camp.length > 25 ? camp.substring(0, 22) + '...' : camp,
    spend: Number(campaignMap[camp].cost.toFixed(2)),
    conversions: campaignMap[camp].conversions,
    roas: campaignMap[camp].cost > 0 ? Number((campaignMap[camp].value / campaignMap[camp].cost).toFixed(2)) : 0
  })).slice(0, 8);

  const blockTerms = terms.filter(t => (t.reviewer_action || t.recommendation) === 'BLOCK');
  const totalPotentialSpendOnBlocks = blockTerms.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);
  const wasteCandidates = blockTerms.sort((a, b) => b.cost - a.cost).slice(0, 8);

  const opportunities = terms
    .filter(t => (t.reviewer_action || t.recommendation) === 'PROMOTE')
    .sort((a, b) => b.conversion_value - a.conversion_value)
    .slice(0, 8);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Dataset Active ({totalTerms.toLocaleString()} rows reconciled)</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">Turn Search Terms into Smarter Advertising Decisions</h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Reconciled metrics for <span className="text-white font-semibold">Kestrel Business Funding</span>. Total Spend: <span className="text-white font-semibold">${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span> | Total Conversions: <span className="text-white font-semibold">{totalConversions.toLocaleString()}</span>. Potential Spend on Block Candidates: <span className="text-emerald-400 font-semibold">${totalPotentialSpendOnBlocks.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 relative z-10 shrink-0">
          <button
            onClick={onLoadDemo}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 transition-all flex items-center gap-1.5"
            title="Reset to Demo State"
          >
            <RefreshCcw className="h-3.5 w-3.5" />
            <span>Reset Demo</span>
          </button>
          <button
            onClick={() => onNavigate('terms')}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2"
          >
            <span>Explore Search Terms</span>
            <ArrowUpRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Ad Spend</span>
            <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <DollarSign className="h-4 w-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900">${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
            <p className="text-xs text-slate-500 mt-1">{totalClicks.toLocaleString()} total clicks ({totalImpressions.toLocaleString()} imp)</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Conversions & Value</span>
            <div className="h-8 w-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Target className="h-4 w-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900">{totalConversions.toLocaleString()} <span className="text-sm font-normal text-slate-500">(${totalValue.toLocaleString(undefined, {minimumFractionDigits: 0})})</span></div>
            <p className="text-xs text-emerald-600 font-medium mt-1">ROAS: {overallROAS.toFixed(2)}x | CVR: {overallCVR.toFixed(2)}%</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Cost Per Conversion</span>
            <div className="h-8 w-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900">${overallCPA.toFixed(2)}</div>
            <p className="text-xs text-slate-500 mt-1">Average CPA across all terms</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Triage Breakdown</span>
            <div className="h-8 w-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <CheckCircle2 className="h-4 w-4" />
            </div>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-xs font-bold" title="Promote">{counts.PROMOTE} P</span>
            <span className="px-2 py-0.5 rounded bg-red-100 text-red-800 text-xs font-bold" title="Block">{counts.BLOCK} B</span>
            <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-xs font-bold" title="Review">{counts.REVIEW} R</span>
            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-xs font-bold" title="Ignore">{counts.IGNORE} I</span>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs lg:col-span-2 flex flex-col">
          <h3 className="text-base font-bold text-slate-900 mb-4">Campaign Performance (Spend & Conversions)</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={campaignChartData} margin={{ top: 10, right: 30, left: 0, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" angle={-15} textAnchor="end" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="left" orientation="left" stroke="#3B82F6" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="right" orientation="right" stroke="#10B981" tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="spend" name="Spend ($)" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="conversions" name="Conversions" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <h3 className="text-base font-bold text-slate-900 mb-2">Triage Classification</h3>
          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tables: Potential Spend on Block Candidates & Growth Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-200 bg-red-50/50 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertOctagon className="h-5 w-5 text-red-600" />
                <h3 className="font-bold text-slate-900">Potential Spend on Block Candidates</h3>
              </div>
              <span className="text-xs font-semibold text-red-700 bg-red-100 px-2.5 py-1 rounded-full">
                Total: ${totalPotentialSpendOnBlocks.toLocaleString(undefined, {minimumFractionDigits: 2})}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 leading-normal flex items-center gap-1">
              <Info className="h-3.5 w-3.5 text-slate-400 shrink-0" />
              <span>Calculated as the exact sum of costs for all terms classified as BLOCK. Actual recoverable savings depend on future traffic and campaign adjustments.</span>
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                  <th className="p-3">Search Term</th>
                  <th className="p-3">Campaign</th>
                  <th className="p-3 text-right">Cost</th>
                  <th className="p-3 text-right">Clicks</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {wasteCandidates.map((t) => (
                  <tr key={t.row_id} className="hover:bg-slate-50/80">
                    <td className="p-3 font-semibold text-slate-800">{t.search_term}</td>
                    <td className="p-3 text-slate-500">{t.campaign}</td>
                    <td className="p-3 text-right font-medium text-red-600">${t.cost.toFixed(2)}</td>
                    <td className="p-3 text-right text-slate-600">{t.clicks}</td>
                    <td className="p-3 text-center">
                      <span className="px-2 py-0.5 rounded bg-red-100 text-red-700 font-bold text-[10px]">BLOCK</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-200 bg-emerald-50/50 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900">Top Growth Opportunities (PROMOTE)</h3>
              </div>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full">
                {counts.PROMOTE} Promote Recommendations
              </span>
            </div>
            <p className="text-[11px] text-slate-500 leading-normal flex items-center gap-1">
              <Info className="h-3.5 w-3.5 text-slate-400 shrink-0" />
              <span>Recommended investment opportunities based on high commercial intent and positive ROAS.</span>
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                  <th className="p-3">Search Term</th>
                  <th className="p-3 text-right">Conversions</th>
                  <th className="p-3 text-right">ROAS</th>
                  <th className="p-3 text-right">Value</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {opportunities.map((t) => (
                  <tr key={t.row_id} className="hover:bg-slate-50/80">
                    <td className="p-3 font-semibold text-slate-800">{t.search_term}</td>
                    <td className="p-3 text-right font-medium text-emerald-600">{t.conversions}</td>
                    <td className="p-3 text-right font-bold text-slate-700">{t.roas.toFixed(2)}x</td>
                    <td className="p-3 text-right text-slate-600">${t.conversion_value.toLocaleString()}</td>
                    <td className="p-3 text-center">
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 font-bold text-[10px]">PROMOTE</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
