import React from 'react';
import { SearchTermItem } from '../types';
import { FileText, Download, Sparkles, AlertOctagon, CheckCircle2 } from 'lucide-react';

interface ReportsViewProps {
  terms: SearchTermItem[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ terms }) => {
  const downloadReport = (type: string) => {
    let filtered = terms;
    if (type === 'promote') filtered = terms.filter(t => (t.reviewer_action || t.recommendation) === 'PROMOTE');
    else if (type === 'block') filtered = terms.filter(t => (t.reviewer_action || t.recommendation) === 'BLOCK');
    else if (type === 'review') filtered = terms.filter(t => (t.reviewer_action || t.recommendation) === 'REVIEW');

    const csvHeader = "row_id,search_term,match_type,campaign,ad_group,impressions,clicks,cost,conversions,conversion_value,recommendation,confidence,intent_category\n";
    const csvRows = filtered.map(t => 
      `"${t.row_id}","${t.search_term}","${t.match_type}","${t.campaign}","${t.ad_group}",${t.impressions},${t.clicks},${t.cost},${t.conversions},${t.conversion_value},"${t.reviewer_action || t.recommendation}",${t.confidence},"${t.intent_category}"`
    ).join("\n");

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `kestrel_search_terms_${type}_report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadComprehensiveReport = () => {
    const totalCost = terms.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);
    const totalConversions = terms.reduce((acc, t) => acc + (Number(t.conversions) || 0), 0);
    const blockTerms = terms.filter(t => (t.reviewer_action || t.recommendation) === 'BLOCK');
    const totalPotentialSpend = blockTerms.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);

    const report = {
      title: "Kestrel Business Funding - Search Term Triage Comprehensive Analysis Report",
      generated_at: new Date().toISOString(),
      summary: {
        total_terms_analyzed: terms.length,
        total_spend: totalCost.toFixed(2),
        total_conversions: totalConversions,
        potential_spend_on_block_candidates: totalPotentialSpend.toFixed(2),
        classification_counts: {
          promote: terms.filter(t => (t.reviewer_action || t.recommendation) === 'PROMOTE').length,
          block: blockTerms.length,
          review: terms.filter(t => (t.reviewer_action || t.recommendation) === 'REVIEW').length,
          ignore: terms.filter(t => (t.reviewer_action || t.recommendation) === 'IGNORE').length
        }
      },
      block_candidates_breakdown: blockTerms.map(t => ({
        search_term: t.search_term,
        campaign: t.campaign,
        cost: t.cost,
        clicks: t.clicks,
        conversions: t.conversions,
        explanation: t.explanation
      })),
      all_terms_audit: terms.map(t => ({
        row_id: t.row_id,
        search_term: t.search_term,
        recommendation: t.recommendation,
        reviewer_action: t.reviewer_action || 'None',
        reviewer_notes: t.reviewer_notes || '',
        confidence: t.confidence,
        intent_category: t.intent_category
      }))
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'kestrel_comprehensive_analysis_report.json');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Reports & Analysis Exports</h2>
          <p className="text-sm text-slate-500">Download targeted optimization reports, negative keyword lists, and comprehensive judge-ready JSON summaries.</p>
        </div>
        <button
          onClick={downloadComprehensiveReport}
          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
        >
          <Download className="h-4 w-4 text-emerald-400" />
          <span>Download Comprehensive Report (JSON)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Promotion Opportunities</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              High-intent search terms with positive ROAS recommended for bid increases or exact-match expansion.
            </p>
          </div>
          <button
            onClick={() => downloadReport('promote')}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Download Promotion CSV</span>
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
              <AlertOctagon className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Negative Keyword Candidates</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Unsupported products, personal loans, grants, and high-spend zero-conversion waste candidates.
            </p>
          </div>
          <button
            onClick={() => downloadReport('block')}
            className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Download Negative Keywords CSV</span>
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <FileText className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Ambiguous Review Queue</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Terms with low sample size or ambiguous intent requiring human reviewer assessment.
            </p>
          </div>
          <button
            onClick={() => downloadReport('review')}
            className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Download Review Queue CSV</span>
          </button>
        </div>
      </div>
    </div>
  );
};
