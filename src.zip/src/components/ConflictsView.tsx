import React from 'react';
import { SearchTermItem } from '../types';
import { AlertTriangle, ShieldAlert } from 'lucide-react';
import { clusterSearchTerms } from '../utils/clustering';

interface ConflictsViewProps {
  terms: SearchTermItem[];
}

export const ConflictsView: React.FC<ConflictsViewProps> = ({ terms }) => {
  const clusters = clusterSearchTerms(terms).filter(c => c.hasConflict);

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900">Conflict Detection & Resolution</h2>
        <p className="text-sm text-slate-500">Clusters or related search terms containing conflicting triage recommendations (e.g. Promote vs Block).</p>
      </div>

      {clusters.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
          <div className="h-12 w-12 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No Conflicting Recommendations Detected</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">All search term clusters have consistent triage recommendations or have been reviewed.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {clusters.map((cluster, idx) => (
            <div key={idx} className="bg-white rounded-2xl border border-amber-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Conflict in Cluster: {cluster.clusterName}</h3>
                  <p className="text-xs text-slate-500">Different terms in this cluster received conflicting recommendations.</p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                      <th className="p-3">Search Term</th>
                      <th className="p-3 text-right">Clicks</th>
                      <th className="p-3 text-right">Cost</th>
                      <th className="p-3 text-right">Conversions</th>
                      <th className="p-3 text-center">Recommendation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {cluster.terms.map((t) => (
                      <tr key={t.row_id} className="hover:bg-slate-50/80">
                        <td className="p-3 font-semibold text-slate-900">{t.search_term}</td>
                        <td className="p-3 text-right">{t.clicks}</td>
                        <td className="p-3 text-right">${t.cost.toFixed(2)}</td>
                        <td className="p-3 text-right">{t.conversions}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            (t.reviewer_action || t.recommendation) === 'PROMOTE' ? 'bg-emerald-100 text-emerald-800' :
                            (t.reviewer_action || t.recommendation) === 'BLOCK' ? 'bg-red-100 text-red-800' :
                            'bg-amber-100 text-amber-800'
                          }`}>
                            {t.reviewer_action || t.recommendation}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
